<?php /* Template Name: qrcode-menu */ ?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
      *{
        box-sizing: border-box;
      }
      body{
        padding: 0;
        margin: 0px;
        background-color: #fff;
      }
    </style>
  </head>
  <body>
    <div>Test</div>
  </body>
</html>