<?php wp_footer(); ?>
<footer>
            <div class="ftrRow1">
                <div class="container">
                    <div class="FtrRowCnt">
                        <div class="row">
                            <div class="col-md-3 FirstClmn">
                                <a href="/"><img class="img-fluid  wow slideInUp" src="https://mccollinsmediaweb.github.io/felis-kitchen/assets/images/logo-feliz.svg" alt=""></a>
                                <div>
                                    <div class="SocilTp1">
                                        <a href="https://www.facebook.com/feliskitchen" target="_blank">
                                            <span class="FtIcon  wow slideInUp">&nbsp;</span>
                                        </a>
                                        <a href="https://www.instagram.com/feliskitchen/" target="_blank">
                                            <span class="FtIcon insta  wow slideInUp">&nbsp;</span>
                                        </a>
                                        <a href="https://www.youtube.com/watch?v=YKPac8hyrfk&t=4s" target="_blank">
                                            <span class="FtIcon youtube  wow slideInUp">&nbsp;</span>
                                        </a>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3 seCondColumn">
                                <ul>
                                    <li>
                                        <a href="/" class=" wow slideInUp">Home</a>
                                    </li>
                                    <li>
                                        <a href="/our-story/" class=" wow slideInUp">Our Story</a>
                                    </li>
                                    <li>
                                        <a href="/products/" class=" wow slideInUp">Products</a>
                                    </li>
                                    <li>
                                        <a href="/contactus/" class=" wow slideInUp">Contact Us </a>
                                    </li>
                                </ul>
                            </div>
                            <div class="col-md-3 seCondColumn">
                                <ul>
                                    
                                    <!--<li>-->
                                    <!--    <a href="/privacy-policy/" class=" wow slideInUp">Privacy Policy</a>-->
                                    <!--</li>-->
                                    <!--<li>-->
                                    <!--    <a href="/terms-and-condition/" class=" wow slideInUp">Terms & Conditions</a>-->
                                    <!--</li>-->
                                    
                                    <li>
                                        <a href="/tips/" class=" wow slideInUp">Tips </a>
                                    </li>
                                    <li>
                                        <a href="/partners/" class=" wow slideInUp">Partners </a>
                                    </li>
                                    <li>
                                        <a href="https://api.whatsapp.com/send?phone=971506446826&text=Hello%2C%20I%20would%20like%20to%20know%20more%20about%20Felis%20Kitchen" class=" wow slideInUp">Let's Chat</a>
                                    </li>
                                    <li>
                                        <a href="/faq/" class=" wow slideInUp">FAQ</a>
                                    </li>
                                </ul>
                            </div>
                            <div class="col-md-3 LastColumn">
                                <div>
                                    <div class="AdRow1 wow slideInUp">
                                        <div class="AdIcon">
                                            <span class="AdIconSp"></span>
                                        </div>
                                        <div class="AdCnt">
                                            Felis Kitchen,
                                            Dubai, United Arab Emirates
                                        </div>
                                    </div>
                                </div>
                                <div>
                                    <div class="AdRow1 wow slideInUp">
                                        <div class="AdIcon">
                                            <span class="AdIconSp email"></span>
                                        </div>
                                        <div class="AdCnt">
                                            <!--info@feliskitchen.com<br/>-->
feli@feliskitchen.com
                                        </div>
                                    </div>
                                </div>
                                <div>
                                    <div class="AdRow1 wow slideInUp">
                                        <div class="AdIcon">
                                            <span class="AdIconSp call"></span>
                                        </div>
                                        <div class="AdCnt">‎+971506446826
                                        </div>
                                    </div>
                                </div>
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
        <div class="PowereBy">
            © Copyrights 2022. Feli’s Kitchen. All rights reserved. Powered by <a target="_blank" href="https://mccollinsmedia.com/">McCollins Media</a>
        </div>
    </div>
    <script type="text/javascript" src="https://mccollinsmediaweb.github.io/felis-kitchen/assets/js/fl-plugins.js"></script>
    <script type="text/javascript" src="https://mccollinsmediaweb.github.io/felis-kitchen/assets/js/fl-main.js"></script>
    <script>
    document.addEventListener( 'wpcf7mailsent', function( event ) {
        location = '/thank-you/';
    }, false );
    </script>
    <script>
        $(window).on('load', function () {
            $('.preloader').hide();
        }) 
    </script>
	<!-- <script>
		$(document).ready(function() {

        $('#html5Video').on('hidden.bs.modal', function() {
        var html5Video = document.getElementById("htmlVideo");
        if (html5Video != null) {
            html5Video.pause();
            html5Video.currentTime = 0;
        }
        });
        });
	</script> -->
    <script type="text/javascript" src="https://mccollinsmediaweb.github.io/felis-kitchen/assets/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-fQybjgWLrvvRgtW6bFlB7jaZrFsaBXjsOMm/tB9LTS58ONXgqbR9W8oWht/amnpF" crossorigin="anonymous"></script>
</body>
</html>
